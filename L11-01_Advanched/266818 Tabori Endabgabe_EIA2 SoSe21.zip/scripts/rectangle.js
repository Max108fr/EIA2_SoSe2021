"use strict";
var EIA2Endabgabe;
(function (EIA2Endabgabe) {
    class Rectangle {
        constructor(_pos, _width, _height) {
            this.position = _pos;
            this.width = _width;
            this.height = _height;
        }
    }
    EIA2Endabgabe.Rectangle = Rectangle;
})(EIA2Endabgabe || (EIA2Endabgabe = {}));
//# sourceMappingURL=rectangle.js.map